# Maturita - úkol 3

Jedná se o vite projekt, lze spusit pomocí příkazu `yarn dev` (pro využití npm smažte yarn.lock a `npm install`)

Přikládám i zkompilovanou verzi ve složce /dist