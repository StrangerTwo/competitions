/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.ts",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
