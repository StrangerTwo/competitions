import { Road } from "./main";

const getRoadsToUpgrade = (_roads: Road[]): Road[] => {
    const result: Road[] = []

    return result;
}

export default getRoadsToUpgrade;