# Maturita - úkol 2

Jedná se o npm projekt, lze spusit pomocí příkazu `yarn start` (pro využití npm smažte yarn.lock a `npm install`)

Aplikace se zeptá na polohu souboru `squares.dat` s interaktivním výběrem, soubor obrázku je uložen ve složce s `index.ts` pod jménem `qr.png`

Zkompilované .js soubory jsou ve složce `/build` - i zde je však třeba nainstalovat balíčky `npm`