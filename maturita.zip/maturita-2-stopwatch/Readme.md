# Maturita - úkol 2

Jedná se o npm projekt, lze spusit pomocí příkazu `yarn start` (pro využití npm smažte yarn.lock a `npm install`)

Třída Stopwatch se nachází v souboru stopwatch.ts

Zkompilované .js soubory jsou ve složce `/build`