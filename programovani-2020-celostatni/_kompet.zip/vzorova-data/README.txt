Ikonky můžete použít k zobrazení, ale nemusíte, můžete dokonce použít i své vlastní.

Vstupní soubory se stejným jménem ale jinou příponou (.txt a .json) popisují stejnou mapu. 

Soubor s názvem "AI_Level_4_Distance_6_or_Energy_13" znamená "tuto mapu je možné vyřešit umělou inteligencí, má obtížnost 4, nejkratší cesta ze startu do cíle ujde 6 políček, a při cestě ze startu do cíle, při které Pac-Manovi zbyde v cíli nejvíce energie, mu v cíli zbyde 13 energetických jednotek. Tato cesta může být delší než nejkratší cesta.